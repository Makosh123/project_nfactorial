package com.example.fireboy_and_watergirl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
